import 'package:flutter/material.dart';

class DrawDate extends StatelessWidget {
  const DrawDate({
    @required this.color,
    @required this.weekDay,
    @required this.date,
    @required this.month,
  })  : assert(color != null),
        assert(weekDay != null),
        assert(date != null),
        assert(month != null);

  final Color color;
  final String weekDay;
  final String date;
  final String month;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(left: 50.0, right: 50.0),
        child: IntrinsicHeight(
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 40.0,
                      child: Text(
                        weekDay.toUpperCase(),
                        style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.w900,
                          foreground: Paint()
                            ..style = PaintingStyle.stroke
                            ..strokeWidth = 1
                            ..color = color,
                        ),
                      ),
                    ),
                    Container(
                      height: 40.0,
                      child: Text(
                        month.toUpperCase(),
                        style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.w900,
                          foreground: Paint()
                            ..style = PaintingStyle.stroke
                            ..strokeWidth = 1
                            ..color = color,
                        ),
                      ),
                    ),
                  ]),
            ),
            Expanded(
              child: Container(
                child: Text(
                  date,
                  style: TextStyle(
                    fontSize: 90,
                    fontWeight: FontWeight.w900,
                    foreground: Paint()
                      ..style = PaintingStyle.stroke
                      ..strokeWidth = 2
                      ..color = color,
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
